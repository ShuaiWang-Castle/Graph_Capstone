# 结果声明范围独立审阅

建议本轮主状态用 **NO_REPRODUCIBLE_GAIN**，准确展开为：**未获得通过冻结的全格或有限范围准入规则的可重复质量—成本改进；n5000 存在三算法种子一致的局部开发加速现象，但未获准进入独立确认。** 确认门保持关闭，不生成或运行 211/212 确认图，不放宽 −0.01、不按图规模选择后端。

这不是“全部现象都没有一致方向”。任务书没有给五个状态互斥的充要定义，以上是按既有冻结准入规则解释报告状态，不是另立规则。`DEV_SIGNAL_ONLY` 可作为局部现象的描述；作为本轮单一主状态，容易误解为已有获准确认的开发改进、只是尚未确认，故更建议主状态加上述限定。不得用局部信号绕过冻结的质量准入。

## 原文与实际数据

`GOAL_MODE_PROMPT_ZH.md:93` 要求“候选在所有24个开发case保留原结果与失败，再检查74/75种子稳定性”，第95行阶段标题为“有可重复开发改善，才冻结确认实验”；第97行说明确认种子“只是预指定，尚未运行”。第114行明确状态“是本轮执行结论，不是论文录用判断”。第91行要求普通向量化/缓存“如实标作工程改进”。

更具体的冻结条件 `configs/candidate_gate_v1.json:39` 原文是 “n5000 only allowed if all three seeds there pass speed and both-size quality gates”；第43行要求 “both n1000 and n5000 for each algorithm seed pass macro/micro mean quality and status gates”。第29行均值质量容差为 −0.01，第34行配对中位节时阈值为 0.1，第52行是 “Only stable development signal after all three seeds.” 因而局部大图速度超过阈值不能替代两种规模的质量准入。

| 对照范围 | 算法 seed73 | seed74 | seed75 |
|---|---:|---:|---:|
| CSR vs elementwise，n5000 配对中位节时 | 18.4766% | 17.1480% | 17.4531% |
| CSR vs BMM，n5000 配对中位节时 | 22.0266% | 21.4058% | 20.5499% |
| CSR vs elementwise，n1000 配对中位节时 | −7.9448% | −7.4585% | −7.3164% |

每层均保留 12 个已完成且已评分配对，候选新增 incomplete 为 0。CSR n5000 的 macro/micro 平均差均满足 −0.01 容差；但 n1000/seed75 的宏F1平均差 **−0.010814400079310291**，低于 −0.01，越界约 0.0008144 仍按原标准失败。这里不能把接近阈值转成通过，也不能把实用容差理解为统计非劣效证明。

BMM 六层宏/微均值质量通过，但配对中位节时全部为负（变慢约2.17–4.50%），不满足全格或大图有限范围速度门槛。实际 `gate-analysis.json` 的 CSR quality/status eligibility=false，BMM eligibility=true，但双方 claim_scope=none，selected_claim_scope=none，confirmation_gate_open=false。重新仅按 `strata.csv` 与冻结门槛核算这些 flags 全部一致。selected_global_backend=BMM 是符合质量的候选排序结果，不能称为赢家或已冻结的确认算法。

## 退化保留与列表范围

原 `regressions.csv` 的 53 行包含 23 条 BMM_vs_elementwise 与 30 条 CSR_vs_elementwise，仅覆盖主对照。CSR 对 elementwise 在 n1000 有5项 macro/micro 材料退化，例如 `lfr_n1000_o20_m50_s11 / seed75` 宏差 −0.0668387065、微差 −0.0601914880、至少两正确归属召回差 −0.125。n5000 对主对照没有达到 −0.03 的 macro/micro 材料退化，仍有至少两归属恢复退化，不能写逐例无退化。

大图对 BMM 也不能说无材料退化：`lfr_n5000_o00_m20_s12 / seed74` 的 CSR−BMM 宏差 −0.0367387004、微差 −0.0248361962。为完整披露，在本目录 `ALL_EXISTING_PAIR_REGRESSIONS.csv` 按原 `pairs.csv` 的两个既有 flags 原样筛取全部比较：主对照53条、CSR_vs_BMM 27条、cap1000_vs_500 7条，共87条。没有重新计算指标、定义新阈值或修改原列表。原 `pairs.csv` 始终保留全部配对，材料退化列表仅是其诊断索引。

## 能与不能声称

可以声称：本次 CPU1、graph-only、oracle-K、固定参数与完整 pipeline 成本下，CSR 在预登记 n5000 开发子集有跨三个算法种子的中位加速观察；它在 n1000 变慢且有一层质量均值越界，因而冻结准入失败。完整失败和局部正向事实可以同时交付。最多两个候选是上限，不要求为制造赢家而补造第二机制。

不能声称：严格同质量、逐例或整体支配、统计非劣效或显著性、新种子独立确认、其他生成器/degree-only负例或真实图泛化、跨硬件或 native-K 优势、全部速度差都由一个原语独立因果解释、新算法原理、顶会认可或投稿就绪。详细 profile 属于另外的诊断，不改 headline pipeline 时间，也不能重新打开确认门。冻结 gate 第54行明确为 “descriptive predeclared practical criteria, not IID confidence intervals, p values or statistical noninferiority theorem”。

已读 Supervisor-Skills `idea-evaluator` 与 `fatal-flaws`，仅借用数据反驳、F6不可验证主张与F10失败披露纪律。该技能完整流程针对开题，并明确已实现工作不适用；本次不执行形式评分、投稿判决或新颖性结论。其“Reject and Pivot”不能覆盖用户禁止自动换题的指令：这里拒绝超出证据的正向主张，继续交付负面实验结果。所读技能和上游 CC-BY-4.0 许可证已原样复制到 `upstream_skills/`，commit 固定为 `207bc6f7a1aa107e544099c2c7cc86816fba9628`。

本审阅仅解析既有小型汇总表，不读取真标签、不训练、不评分、不运行测量、不改变规则。源码/配置与结果输入 SHA-256、原文行号、重新核对 flags、范围限制和退化列表来源见 `SCIENTIFIC_SCOPE_EVIDENCE.json`；全部审阅输入字节哈希保持不变。
